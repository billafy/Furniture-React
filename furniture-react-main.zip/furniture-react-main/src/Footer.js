import React from 'react';

const Footer = () => {
	return (
		<>
			<h3>Footer</h3>
		</>	
	);
}

export default Footer;