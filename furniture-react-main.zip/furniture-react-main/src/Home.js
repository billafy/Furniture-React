import React from 'react';

const Home = () => {
	return (
		<>
			<h3>Home</h3>
		</>	
	);
}

export default Home;