import React from 'react';

const Cart = () => {
	return (
		<>
			<h3>Cart</h3>
		</>	
	);
}

export default Cart;