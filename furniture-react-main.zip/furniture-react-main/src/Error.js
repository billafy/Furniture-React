import React from 'react';

const Error = () => {
	return (
		<>
			<h3>Error</h3>
		</>	
	);
}

export default Error;